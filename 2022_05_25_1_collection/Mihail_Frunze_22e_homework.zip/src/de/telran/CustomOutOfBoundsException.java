package de.telran;

public class CustomOutOfBoundsException extends RuntimeException{
}
